const API_BASE = "https://web-campus-guide-uph.vercel.app";

(async function secureSessionCheck() {
  try {
    const res = await fetch(`${API_BASE}/auth/me`, {
      method: "GET",
      credentials: "include"
    });

    // Not authenticated → redirect
    if (res.status === 401) {
      alert("Not authenticated. Redirecting...");
      window.location.href = "../user-screens/map-screen.html";
      return;
    }

    // Logged in but not an admin → redirect
    if (res.status === 403) {
      alert("You are not an admin. Redirecting...");
      window.location.href = "../user-screens/map-screen.html";
      return;
    }

    // Any other error → redirect
    if (!res.ok) {
      alert("Session error. Redirecting...");
      window.location.href = "../user-screens/map-screen.html";
      return;
    }

    // Success → authenticated AND admin
    const user = await res.json();
    console.log(user.id, user.email);
    console.log("Admin authenticated:", user.email);

  } catch (err) {
    console.error("Session check error:", err);
    window.location.href = "../user-screens/map-screen.html";
  }
})();

const tableBody = document.querySelector("tbody");

// Format timestamp → readable date
function formatDate(ms) {
  const d = new Date(ms);
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

// Convert minutes to HH:MM
function formatTime(start, end) {
  const toStr = (m) =>
    `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;

  return `${toStr(start)}–${toStr(end)}`;
}

// Detect Past event
function isPastEvent(event) {
  const today = new Date().setHours(0, 0, 0, 0);
  const eventDay = new Date(event.date).setHours(0, 0, 0, 0);
  return eventDay < today;
}

async function loadHistory() {
  try {
    const res = await fetch(`${API_BASE}/events`);
    if (!res.ok) throw new Error("Failed to load history");

    const data = await res.json();
    const events = Object.values(data);

    // ⭐ Only show Past events
    const pastEvents = events.filter(isPastEvent);

    // ⭐ Sort newest → oldest
    pastEvents.sort((a, b) => b.date - a.date);

    tableBody.innerHTML = "";

    if (pastEvents.length === 0) {
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = 5;
      td.textContent = "No past events available.";
      td.style.textAlign = "center";
      tr.appendChild(td);
      tableBody.appendChild(tr);
      return;
    }

    // Render list
    pastEvents.forEach((event, index) => {
      const tr = document.createElement("tr");

      tr.innerHTML = `
        <td>${index + 1}</td>
        <td>${event.name || "-"}</td>
        <td>${event.heldBy || "-"}</td>
        <td>${formatTime(event.startTimeMinutes, event.endTimeMinutes)}</td>
        <td>${formatDate(event.date)}</td>
      `;

      tableBody.appendChild(tr);
    });

  } catch (err) {
    console.error(err);

    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 5;
    td.textContent = "Error loading event history.";
    td.style.textAlign = "center";
    tr.appendChild(td);
    tableBody.appendChild(tr);
  }
}

// Load when page opens
window.addEventListener("DOMContentLoaded", loadHistory);
