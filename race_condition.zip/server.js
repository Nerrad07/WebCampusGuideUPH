// server.js — Express API with Firebase Admin + Email/Password Auth on backend

import express from "express";
import dotenv from "dotenv";
import admin from "firebase-admin";
import cors from "cors";
import session from "express-session";
import multer from "multer"; // for file uploads
import fetch from "node-fetch"; // for Firebase Auth REST API

dotenv.config();

const app = express();

// ------------------------------
// Firebase Admin Initialization
// ------------------------------
const serviceAccount = JSON.parse(process.env.SERVICE_ACCOUNT);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: process.env.DATABASE_URL,
  storageBucket: process.env.STORAGE_BUCKET, // MUST be xxxx.appspot.com
});

// Realtime DB + Storage
const db = admin.database();
const bucket = admin.storage().bucket();

// Multer (store file in memory)
const upload = multer({ storage: multer.memoryStorage() });

// ------------------------------
// Middleware
// ------------------------------
app.set("trust proxy", 1);
const isProd = process.env.NODE_ENV === "production";

app.use(
  cors({
    origin: [
      "https://web-campus-guide-uph.vercel.app",
      "http://localhost:5500",
      "http://127.0.0.1:5500",
    ],
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  })
);

app.use(express.json());

app.use(
  session({
    secret: process.env.SESSION_SECRET || "supersecretkey",
    resave: false,
    saveUninitialized: false,
    proxy: true,
    cookie: {
      httpOnly: true,
      secure: isProd,
      sameSite: isProd ? "none" : "lax",
      maxAge: 1000 * 60 * 60 * 6, // 6 hours
    },
  })
);

// ------------------------------
// Authentication login and logout
// ------------------------------

// Backend-only auth: verify email+password via Firebase Auth REST
app.post("/auth/login", async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Missing email or password" });
  }

  try {
    // 1) Validate credentials against Firebase Auth using REST API
    const resp = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${process.env.FIREBASE_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email,
          password,
          returnSecureToken: true,
        }),
      }
    );

    if (!resp.ok) {
      const errData = await resp.json().catch(() => ({}));
      console.error("Firebase password verify failed:", errData);
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const data = await resp.json();
    const userId = data.localId; // Firebase uid

    // 2) Check admin role in Realtime Database: admins/<uid>
    const snap = await db.ref("admins/" + userId).once("value");
    if (!snap.exists()) {
      return res.status(403).json({ message: "User is not an admin" });
    }

    // 3) Create session for this admin
    req.session.user = {
      id: userId,
      email: data.email,
      isAdmin: true,
    };

    return res.json({ success: true, user: req.session.user });
  } catch (err) {
    console.error("LOGIN ERROR:", err);
    return res.status(500).json({ message: "Internal server error" });
  }
});

app.post("/auth/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({ success: true });
  });
});

// Who am I?
app.get("/auth/me", async (req, res) => {
  try {
    // 1. Reject if no session found
    if (!req.session.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const { id, email } = req.session.user;

    // 2. Check if user exists in /admins
    const snap = await db.ref("admins/" + id).once("value");

    if (!snap.exists()) {
      return res.status(403).json({ message: "User no longer an admin" });
    }

    const isAdmin = snap.child("isAdmin").val();

    if (!isAdmin) {
      return res.status(403).json({ message: "User is not an admin" });
    }

    // 3. Return full user object
    return res.json({
      id,
      email,
      isAdmin: true
    });

  } catch (err) {
    console.error("auth/me error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});


// ------------------------------
// POSTER UPLOAD
// ------------------------------
app.post("/uploadPoster/:eventId", upload.single("poster"), async (req, res) => {
  console.log("UploadPoster route hit");
  try {
    const eventId = req.params.eventId;

    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const ext = req.file.originalname.split(".").pop();
    const fileName = `${eventId}.${ext}`;
    const fileRef = bucket.file(`posters/${fileName}`);
    console.log("Saving file to bucket as", fileName);

    await fileRef.save(req.file.buffer, {
      contentType: req.file.mimetype,
      public: true,
    });

    const publicUrl = `https://storage.googleapis.com/${process.env.STORAGE_BUCKET}/posters/${fileName}`;

    const snap = await db.ref(`events/${eventId}`).once("value");
    if (!snap.exists()) {
      return res.status(404).json({ message: "Event not found" });
    }

    await db.ref(`events/${eventId}`).update({ posterUrl: publicUrl });

    res.json({ url: publicUrl });
  } catch (err) {
    console.error("Upload error:", err);
    res.status(500).json({ message: "Upload failed" });
  }
});

// ------------------------------
// Event routes
// ------------------------------
app.get("/events", async (req, res) => {
  try {
    const snapshot = await db.ref("events").once("value");
    res.json(snapshot.val() || {});
  } catch (err) {
    console.error("Fetch events error:", err);
    res.status(500).json({ message: "Failed to fetch events" });
  }
});

app.get("/events/:id", async (req, res) => {
  try {
    const snapshot = await db.ref("events/" + req.params.id).once("value");
    if (!snapshot.exists()) {
      return res.status(404).json({ message: "Event not found" });
    }
    res.json(snapshot.val());
  } catch (err) {
    console.error("Error fetching event:", err);
    res.status(500).json({ message: "Failed to fetch event" });
  }
});

app.post("/events", async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    const newEventRef = db.ref("events").push();
    await newEventRef.set(req.body);
    res.json({ message: "Event created", id: newEventRef.key });
  } catch (err) {
    console.error("Create event error:", err);
    res.status(500).json({ message: "Failed to create event" });
  }
});

app.put("/events/:id", async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    await db.ref(`events/${req.params.id}`).update(req.body);
    res.json({ message: "Event updated" });
  } catch (err) {
    console.error("Update event error:", err);
    res.status(500).json({ message: "Failed to update event" });
  }
});

app.delete("/events/:id", async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    await db.ref(`events/${req.params.id}`).remove();
    res.json({ message: "Event deleted" });
  } catch (err) {
    console.error("Delete event error:", err);
    res.status(500).json({ message: "Failed to delete event" });
  }
});

// ------------------------------
// Start Server
// ------------------------------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on ${PORT}`));
